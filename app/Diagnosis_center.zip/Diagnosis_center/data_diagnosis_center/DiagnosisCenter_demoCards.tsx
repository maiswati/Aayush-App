// data/demoCards.ts

export const demoCards = [
  { id: "", name: "", age: "", gender: "", totalReports: "" },
  { id: "", name: "", age: "", gender: "", totalReports: "" },
  { id: "", name: "", age: "", gender: "", totalReports: "" },
  { id: "", name: "", age: "", gender: "", totalReports: "" },
  { id: "", name: "", age: "", gender: "", totalReports: "" },
];