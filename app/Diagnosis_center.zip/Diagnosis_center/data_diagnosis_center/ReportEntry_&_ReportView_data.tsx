// data.tsx
import React from "react";

// Interfaces
export interface RowType {
  test: string;
  result: string;
  units: string;
  range: string;
}

export interface PatientData {
  name: string;
  ageGender: string;
  doctor: string;
  collectionTime: string;
  patientId: string;
  appointmentId: string;
  sampleType: string;
}

// Initial Rows
export const initialRows: RowType[] = [
  { test: "", result: "", units: "", range: "" },
];

// Initial Patient Data
export const initialPatientData: PatientData = {
  name: "",
  ageGender: "",
  doctor: "",
  collectionTime: "",
  patientId: "",
  appointmentId: "",
  sampleType: "",
};