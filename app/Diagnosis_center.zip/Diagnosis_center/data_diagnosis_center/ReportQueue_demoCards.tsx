// data/reportQueueDemoCards.ts

import { PatientCardType } from "../ReportQueue";

export const reportQueueDemoCards: PatientCardType[] = [
  { name: "", test: "", appointment: "", status: "Urgent/InProgress" },
  { name: "", test: "", appointment: "", status: "Normal/InProgress" },
  { name: "", test: "", appointment: "", status: "Urgent/Completed" },
  { name: "", test: "", appointment: "", status: "Normal/Completed" },
];