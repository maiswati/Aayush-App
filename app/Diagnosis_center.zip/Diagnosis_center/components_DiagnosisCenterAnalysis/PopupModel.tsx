import React from "react";
import { Modal, View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";

interface PopupProps {
  showPopup: boolean;
  popupMsg: string;
  closePopup: () => void;
}

export default function Popup({ showPopup, popupMsg, closePopup }: PopupProps) {
  return (
    <Modal transparent visible={showPopup} animationType="fade">
      <View style={styles.overlay}>
        <View style={styles.box}>
          <Ionicons name="checkmark-circle" size={60} color="#0C7B7B" />

          <Text style={styles.text}>{popupMsg}</Text>

          <TouchableOpacity onPress={closePopup} style={styles.button}>
            <Text style={styles.btnText}>OK</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "center",
    alignItems: "center",
  },
  box: {
    width: "70%",
    backgroundColor: "white",
    borderRadius: 16,
    padding: 25,
    alignItems: "center",
  },
  text: {
    marginTop: 15,
    fontSize: 18,
    fontWeight: "600",
    textAlign: "center",
  },
  button: {
    marginTop: 20,
    paddingVertical: 8,
    paddingHorizontal: 25,
    backgroundColor: "#0C7B7B",
    borderRadius: 8,
  },
  btnText: {
    color: "white",
    fontSize: 16,
  },
});