import React from "react";
import { View, Text, StyleSheet } from "react-native";

export default function TestResultsCard() {
  return (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>Test Results</Text>

      <View style={styles.testHeaderRow}>
        <Text style={styles.testHeader}>Test Name</Text>
        <Text style={styles.testHeader}>Result</Text>
        <Text style={styles.testHeader}>Units</Text>
        <Text style={styles.testHeader}>Normal Range</Text>
      </View>

      <View style={styles.testDataRow}>
        <Text style={styles.testValue}>--</Text>
        <Text style={styles.testValue}>--</Text>
        <Text style={styles.testValue}>--</Text>
        <Text style={styles.testValue}>--</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "white",
    marginVertical: 8,
    padding: 20,
    borderRadius: 18,
  },
  cardTitle: { fontSize: 18, marginBottom: 15, fontFamily: "IBMPlexSans_700Bold" },
  testHeaderRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 10 },
  testHeader: { fontSize: 14, width: "25%", fontFamily: "IBMPlexSans_700Bold" },
  testDataRow: { flexDirection: "row", justifyContent: "space-between" },
  testValue: { fontSize: 14, color: "#777", width: "25%" },
});