import React from "react";
import { View, Text, StyleSheet } from "react-native";

interface PatientData {
  name: string;
  ageGender: string;
  doctor: string;
  collectionTime: string;
  patientId: string;
  appointmentId: string;
  sampleType: string;
}

interface Props {
  patientData: PatientData;
}

export default function PatientDetails({ patientData }: Props) {
  return (
    <View style={styles.card}>
      <Text style={styles.sectionTitle}>Patient & Appointment Details</Text>

      <Text style={styles.label}>Patient Name</Text>
      <Text style={styles.value}>{patientData.name || "---"}</Text>

      <Text style={styles.label}>Age & Gender</Text>
      <Text style={styles.value}>{patientData.ageGender || "---"}</Text>

      <Text style={styles.label}>Referring Doctor</Text>
      <Text style={styles.value}>{patientData.doctor || "---"}</Text>

      <Text style={styles.label}>Collection Time</Text>
      <Text style={styles.value}>{patientData.collectionTime || "---"}</Text>

      <Text style={styles.label}>Patient ID</Text>
      <Text style={styles.value}>{patientData.patientId || "---"}</Text>

      <Text style={styles.label}>Appointment ID</Text>
      <Text style={styles.value}>{patientData.appointmentId || "---"}</Text>

      <Text style={styles.label}>Sample Type</Text>
      <Text style={styles.value}>{patientData.sampleType || "---"}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "white",
    marginVertical: 8,
    padding: 14,
    borderRadius: 12,
  },
  sectionTitle: {
    fontSize: 17,
    color: "#00AA5D",
    fontFamily: "IBMPlexSans_700Bold",
    marginBottom: 12,
  },
  label: {
    fontSize: 14,
    color: "black",
    marginTop: 8,
    fontFamily: "IBMPlexSans_400Regular",
  },
  value: {
    fontSize: 15,
    color: "#222",
    marginTop: 2,
  },
});