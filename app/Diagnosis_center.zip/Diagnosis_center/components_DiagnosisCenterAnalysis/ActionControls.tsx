import React from "react";
import { View, TouchableOpacity, Text, StyleSheet } from "react-native";

interface BaseProps {
  onDraft: () => void;
  onFinalize: () => void;
  allFilled?: boolean; // Optional | Used when finalize must be disabled
}

interface ThreeButtonProps extends BaseProps {
  mode: "three"; // draft + review + finalize
  onReview: () => void;
}

interface TwoButtonProps extends BaseProps {
  mode: "two"; // draft + finalize only
}

type Props = ThreeButtonProps | TwoButtonProps;

export default function ActionControls(props: Props) {
  const { onDraft, onFinalize, allFilled = true } = props;

  return (
    <View style={styles.container}>
      {/* Draft Button */}
      <TouchableOpacity style={styles.draftBtn} onPress={onDraft}>
        <Text style={styles.btnTextDark}>Save as Draft</Text>
      </TouchableOpacity>

      {/* Review Button (Only in Three-Button Mode) */}
      {props.mode === "three" && (
        <TouchableOpacity style={styles.reviewBtn} onPress={props.onReview}>
          <Text style={styles.btnTextDark}>Escalate for Review</Text>
        </TouchableOpacity>
      )}

      {/* Final Button */}
      <TouchableOpacity
        style={[styles.finalBtn, !allFilled && { opacity: 0.5 }]}
        onPress={onFinalize}
        disabled={!allFilled}
      >
        <Text style={styles.btnTextLight}>
          {props.mode === "three"
            ? "Finalize & Approve Report"
            : "Finalize & Submit Report"}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginTop: 10, gap: 12 },

  draftBtn: {
    backgroundColor: "white",
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: "center",
  },

  reviewBtn: {
    backgroundColor: "#7DFF9A",
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: "center",
  },

  finalBtn: {
    backgroundColor: "white",
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: "center",
  },

  btnTextDark: {
    color: "#222",
    fontSize: 16,
    fontWeight: "700",
  },

  btnTextLight: {
    color: "black",
    fontSize: 16,
    fontWeight: "700",
    fontFamily: "IBMPlexSans_700Bold",
  },
});