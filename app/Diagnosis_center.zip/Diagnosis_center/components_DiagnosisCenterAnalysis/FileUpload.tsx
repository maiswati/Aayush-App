import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

interface Props {
  uploadedFile: string | null;
  pickFile: () => void;
}

export default function FileUpload({ uploadedFile, pickFile }: Props) {
  return (
    <View style={styles.card}>
      <Text style={styles.sectionTitle}>Upload Report (Max 10 MB)</Text>
      <TouchableOpacity style={styles.uploadBox} onPress={pickFile}>
        <Text style={styles.uploadText}>
          {uploadedFile ? uploadedFile : "Click to upload or drag & drop"}
        </Text>
        <Text style={styles.uploadHint}>PDF, PNG, JPG, DOCX</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "white",
    marginVertical: 8,
    padding: 14,
    borderRadius: 12,
  },
  sectionTitle: {
    fontSize: 17,
    color: "#00AA5D",
    fontFamily: "IBMPlexSans_700Bold",
    marginBottom: 12,
  },
  uploadBox: {
    borderWidth: 1.5,
    borderColor: "#00AA5D",
    padding: 16,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  uploadText: {
    fontSize: 15,
    color: "black",
    fontFamily: "IBMPlexSans_700Bold",
  },
  uploadHint: {
    fontSize: 12,
    color: "black",
    marginTop: 4,
    fontFamily: "IBMPlexSans_400Regular",
  },
});