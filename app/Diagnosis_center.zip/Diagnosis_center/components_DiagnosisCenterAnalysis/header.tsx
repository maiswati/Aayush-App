import React from "react";
import { View, Text, Image, StyleSheet } from "react-native";
import { LinearGradient } from "expo-linear-gradient";

interface Props {
  title: string; // The title to display in the header
}

export default function Header({ title }: Props) {
  return (
    <LinearGradient
      colors={["#00AA5D", "#7DFF9A", "#41E98A", "#D9FFE9"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.container}
    >
      <View style={styles.inner}>
        <Image
          source={require("../../../assets/images/logo.png")}
          style={styles.logo}
        />
        <Text style={styles.title}>{title}</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#89f336",
    height: 100,
    marginBottom: 20,
  },
  inner: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-evenly",
    padding: 20,
  },
  logo: {
    height: 60,
    width: 40,
  },
  title: {
    fontFamily: "IBMPlexSans_700Bold",
    fontSize: 25,
    marginLeft: 5,
    color: "black",
  },
});