import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";

interface Props {
  item: any;
  onPress: () => void;
}

export default function PatientCard({ item, onPress }: Props) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <View style={styles.cardRow}>
        <View>
          <Text style={styles.name}>{item.name || "Patient Name"}</Text>
          <Text style={styles.info}>ID: {item.id || "----"}</Text>
          <Text style={styles.info}>Age: {item.age || "--"}</Text>
          <Text style={styles.info}>Gender: {item.gender || "--"}</Text>
          <Text style={styles.reports}>
            Number of Reports: {item.totalReports || "--"}
          </Text>
        </View>
        <Ionicons name="chevron-forward" size={24} color="#05A122" />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#dcf2dcff",
    padding: 28,
    borderRadius: 24,
    marginBottom: 18,
    borderWidth: 2,
    borderColor: "#00aa5d",
    elevation: 10,
  },
  cardRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  name: {
    fontSize: 19,
    fontWeight: "bold",
    color: "#003845",
    fontFamily: "IBMPlexSans_700Bold",
  },
  info: {
    marginTop: 4,
    fontSize: 14,
    color: "#5a6b73",
    fontFamily: "IBMPlexSans_400Regular",
  },
  reports: {
    marginTop: 12,
    fontWeight: "600",
    fontSize: 15,
    color: "#05A122",
    fontFamily: "IBMPlexSans_700Bold",
  },
});