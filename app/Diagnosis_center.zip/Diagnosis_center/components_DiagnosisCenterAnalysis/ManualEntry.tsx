import React from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from "react-native";

interface RowType {
  test: string;
  result: string;
  units: string;
  range: string;
}

interface Props {
  rows: RowType[];
  setRows: React.Dispatch<React.SetStateAction<RowType[]>>;
  addRow: () => void;
}

export default function ManualEntry({ rows, setRows, addRow }: Props) {
  return (
    <View style={styles.card}>
      <Text style={styles.sectionTitle}>Manual Result Entry</Text>

      {rows.map((row, index) => (
        <View key={index} style={styles.manualBox}>
          <Text style={styles.inputLabel}>Test Name</Text>
          <TextInput
            placeholder="e.g., Hemoglobin"
            placeholderTextColor="#999"
            style={styles.input}
            value={row.test}
            onChangeText={(t) => {
              const arr = [...rows];
              arr[index].test = t;
              setRows(arr);
            }}
          />

          <Text style={styles.inputLabel}>Result</Text>
          <TextInput
            placeholder="e.g., 13.5"
            placeholderTextColor="#999"
            style={styles.input}
            value={row.result}
            onChangeText={(t) => {
              const arr = [...rows];
              arr[index].result = t;
              setRows(arr);
            }}
          />

          <Text style={styles.inputLabel}>Units</Text>
          <TextInput
            placeholder="e.g., g/dL"
            placeholderTextColor="#999"
            style={styles.input}
            value={row.units}
            onChangeText={(t) => {
              const arr = [...rows];
              arr[index].units = t;
              setRows(arr);
            }}
          />

          <Text style={styles.inputLabel}>Normal Range</Text>
          <TextInput
            placeholder="e.g., 13.5–17.5"
            placeholderTextColor="#999"
            style={styles.input}
            value={row.range}
            onChangeText={(t) => {
              const arr = [...rows];
              arr[index].range = t;
              setRows(arr);
            }}
          />
        </View>
      ))}

      <TouchableOpacity style={styles.addRowBtn} onPress={addRow}>
        <Text style={styles.addRowText}>+ Add Row</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "white",
    marginVertical: 8,
    padding: 14,
    borderRadius: 12,
  },
  sectionTitle: {
    fontSize: 17,
    color: "#00AA5D",
    fontFamily: "IBMPlexSans_700Bold",
    marginBottom: 12,
  },
  manualBox: {
    padding: 12,
    backgroundColor: "#ffffffff",
    borderRadius: 10,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#00AA5D",
  },
  inputLabel: {
    fontSize: 14,
    color: "#444",
    marginBottom: 6,
    fontFamily: "IBMPlexSans_700Bold",
  },
  input: {
    borderWidth: 1,
    borderColor: "#DDD",
    padding: 10,
    borderRadius: 6,
    marginBottom: 12,
    backgroundColor: "white",
    fontSize: 14,
  },
  addRowBtn: {
    borderWidth: 1,
    borderColor: "#00AA5D",
    padding: 10,
    borderRadius: 6,
    alignItems: "center",
    marginTop: 4,
  },
  addRowText: {
    color: "#00AA5D",
    fontFamily: "IBMPlexSans_700Bold",
  },
});