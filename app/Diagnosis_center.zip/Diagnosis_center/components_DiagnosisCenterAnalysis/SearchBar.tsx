import React from "react";
import { View, TextInput, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";

interface Props {
  search: string;
  setSearch: (value: string) => void;
}

export default function SearchBar({ search, setSearch }: Props) {
  return (
    <View style={styles.wrapper}>
      <View style={styles.searchBar}>
        <Ionicons name="search" size={20} color="#000" />
        <TextInput
          placeholder="Search by name or patient ID"
          placeholderTextColor="#555"
          style={styles.input}
          value={search}
          onChangeText={setSearch}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    paddingHorizontal: 20,
    marginTop: 10,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#dcf2dcff",
    borderWidth: 2,
    borderColor: "#00aa5d",
    height: 50,
    paddingHorizontal: 14,
    borderRadius: 20,
    elevation: 40,
  },
  input: {
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
    color: "#000",
    fontFamily: "IBMPlexSans_400Regular",
  },
});