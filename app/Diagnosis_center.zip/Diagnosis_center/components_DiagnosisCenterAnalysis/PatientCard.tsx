import { useRouter } from "expo-router";
import React from "react";
import { Text, TouchableOpacity, View } from "react-native";
import { PatientCardType } from "../ReportQueue";
import { styles } from "./ReportQueueStyles";

export default function PatientCard({
  card,
  index,
  isDemo,
}: {
  card: PatientCardType;
  index: number;
  isDemo: boolean;
}) {
  const router = useRouter();

  const handleNavigate = (status: PatientCardType["status"]) => {
    if (status === "Urgent/Completed" || status === "Normal/Completed") {
      router.push("/ViewReport");
    } else {
      router.push("/ReportEntry");
    }
  };

  let statusStyle, statusText;
  switch (card.status) {
    case "Urgent/InProgress":
      statusStyle = styles.urgent;
      statusText = "URGENT / IN PROGRESS";
      break;
    case "Normal/InProgress":
      statusStyle = styles.inProgress;
      statusText = "NORMAL / IN PROGRESS";
      break;
    case "Urgent/Completed":
      statusStyle = styles.urgentCompleted;
      statusText = "URGENT / COMPLETED";
      break;
    case "Normal/Completed":
      statusStyle = styles.completed;
      statusText = "NORMAL / COMPLETED";
      break;
  }

  return (
    <TouchableOpacity
      key={index}
      style={styles.card}
      onPress={() => handleNavigate(card.status)}
    >
      <View style={styles.infoSection}>
        <Text style={styles.name}>
          Name:{!isDemo && card.name ? ` ${card.name}` : ""}
        </Text>
        <Text style={styles.text}>
          Test:{!isDemo && card.test ? ` ${card.test}` : ""}
        </Text>
        <Text style={styles.text}>
          Appointment:{!isDemo && card.appointment ? ` ${card.appointment}` : ""}
        </Text>
      </View>

      <View style={styles.statusBox}>
        <Text style={statusStyle}>{statusText}</Text>
      </View>
    </TouchableOpacity>
  );
}