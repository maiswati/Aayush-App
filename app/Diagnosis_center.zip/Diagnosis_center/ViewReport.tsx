import React, { useState } from "react";
import { View, ScrollView, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { useFonts, IBMPlexSans_400Regular, IBMPlexSans_700Bold } from "@expo-google-fonts/ibm-plex-sans";

import Header from "./components_DiagnosisCenterAnalysis/header";
import PatientDetails from "./components_DiagnosisCenterAnalysis/ReportEntry_&_ReportView_data_Style";
import TestResultsCard from "./components_DiagnosisCenterAnalysis/TestResultsCard";
import ActionControls from "./components_DiagnosisCenterAnalysis/ActionControls";
import PopupModal from "./components_DiagnosisCenterAnalysis/PopupModel";

// ✅ Added data import (only addition)
import { initialPatientData } from "./data_diagnosis_center/ReportEntry_&_ReportView_data";

export default function ViewReport() {
  const [fontsLoaded] = useFonts({
    IBMPlexSans_400Regular,
    IBMPlexSans_700Bold,
  });

  const router = useRouter();

  const [popupVisible, setPopupVisible] = useState(false);
  const [popupMessage, setPopupMessage] = useState("");

  const showPopup = (message: string) => {
    setPopupMessage(message);
    setPopupVisible(true);
  };

  const saveAsDraft = async () => showPopup("Saved as Draft");
  const escalateForReview = async () => showPopup("Escalated for Review");
  const finalizeAndApprove = async () => showPopup("Report Finalized & Approved");

  return (
    <View style={[styles.screen, { backgroundColor: "#F4FEF4" }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 20 }}>
        
        <Header title="View Report" />

        <View style={styles.contentBox}>
          
          {/* ✅ Added patientData prop WITHOUT changing component code */}
          <PatientDetails patientData={initialPatientData} />

          <TestResultsCard />

          <ActionControls
            mode="three"
            onDraft={saveAsDraft}
            onReview={escalateForReview}
            onFinalize={finalizeAndApprove}
          />
        </View>
      </ScrollView>

      <PopupModal
        showPopup={popupVisible}
        popupMsg={popupMessage}
        closePopup={() => setPopupVisible(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },

  contentBox: {
    backgroundColor: "#DCF2DC",
    marginHorizontal: 16,
    borderRadius: 18,
    paddingVertical: 20,
    paddingHorizontal: 10,
    marginTop: 30,
  },
});