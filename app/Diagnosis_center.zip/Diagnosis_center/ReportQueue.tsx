import {
  IBMPlexSans_400Regular,
  IBMPlexSans_700Bold,
  useFonts,
} from "@expo-google-fonts/ibm-plex-sans";
import React, { useEffect, useState } from "react";
import { ScrollView, View } from "react-native";
import PatientCard from "./components_DiagnosisCenterAnalysis/PatientCard";
import { styles } from "./components_DiagnosisCenterAnalysis/ReportQueueStyles";
import Header from "./components_DiagnosisCenterAnalysis/header";

import { reportQueueDemoCards } from "./data_diagnosis_center/ReportQueue_demoCards"; 

export type PatientCardType = {
  name: string;
  test: string;
  appointment: string;
  status:
    | "Urgent/InProgress"
    | "Normal/InProgress"
    | "Urgent/Completed"
    | "Normal/Completed";
};

export default function ReportQueue() {
  const [fontsLoaded] = useFonts({
    IBMPlexSans_400Regular,
    IBMPlexSans_700Bold,
  });

  const [backendCards, setBackendCards] = useState<PatientCardType[]>([]);

  useEffect(() => {
    setBackendCards([]); // backend fetch later
  }, []);

  const cardsToRender =
    backendCards.length > 0
      ? backendCards.map((c, index) => (
          <PatientCard key={index} card={c} index={index} isDemo={false} />
        ))
      : reportQueueDemoCards.map((c, index) => (
          <PatientCard key={index} card={c} index={index} isDemo={true} />
        ));

  return (
    <View style={[styles.container, { backgroundColor: "#F4FEF4" }]}>
      <Header title="Report Queue" />
      <ScrollView style={styles.whiteBox}>{cardsToRender}</ScrollView>
    </View>
  );
}