import React, { useState, useEffect } from "react";
import { View, ScrollView } from "react-native";
import { useFonts, IBMPlexSans_400Regular, IBMPlexSans_700Bold } from "@expo-google-fonts/ibm-plex-sans";
import * as DocumentPicker from "expo-document-picker";

import Header from "./components_DiagnosisCenterAnalysis/header";

// ✅ Correct component added here
import PatientDetails from "./components_DiagnosisCenterAnalysis/ReportEntry_&_ReportView_data_Style";

import FileUpload from "./components_DiagnosisCenterAnalysis/FileUpload";
import ManualEntry from "./components_DiagnosisCenterAnalysis/ManualEntry";
import ActionControls from "./components_DiagnosisCenterAnalysis/ActionControls"; 
import Popup from "./components_DiagnosisCenterAnalysis/PopupModel";

// ✅ Import data
import { RowType, PatientData, initialRows, initialPatientData } from "./data_diagnosis_center/ReportEntry_&_ReportView_data";

export default function ReportEntry() {
  const [fontsLoaded] = useFonts({ IBMPlexSans_400Regular, IBMPlexSans_700Bold });

  const [uploadedFile, setUploadedFile] = useState<string | null>(null);
  const [rows, setRows] = useState<RowType[]>(initialRows);
  const [showPopup, setShowPopup] = useState(false);
  const [popupMsg, setPopupMsg] = useState("");

  const [patientData, setPatientData] = useState<PatientData>(initialPatientData);

  // Fetch patient details
  useEffect(() => {
    async function fetchPatient() {
      try {
        const response = await fetch("https://example.com/api/patient/123");
        const data = await response.json();
        setPatientData(data);
      } catch (error) {
        console.log("Error fetching patient data:", error);
      }
    }
    fetchPatient();
  }, []);

  // Pick file
  const pickFile = async () => {
    let file = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: false });
    if (file.assets && file.assets.length > 0) {
      const selected = file.assets[0];
      const maxSize = 10 * 1024 * 1024;
      if ((selected.size ?? 0) > maxSize) {
        setPopupMsg("File too large! Maximum allowed size is 10 MB.");
        setShowPopup(true);
        return;
      }
      setUploadedFile(selected.name);
    }
  };

  const addRow = () => setRows([...rows, { test: "", result: "", units: "", range: "" }]);

  const allFilled =
    uploadedFile &&
    rows.every((r) => r.test.trim() && r.result.trim() && r.units.trim() && r.range.trim());

  const saveDraft = async () => {
    try {
      await fetch("https://example.com/api/saveDraft", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ uploadedFile, rows }),
      });
      setPopupMsg("Saved as Draft!");
      setShowPopup(true);
    } catch (error) {
      console.log("Error saving draft:", error);
      setPopupMsg("Failed to save draft.");
      setShowPopup(true);
    }
  };

  const finalize = async () => {
    if (!allFilled) {
      setPopupMsg("Please fill all details before finalizing.");
      setShowPopup(true);
      return;
    }
    try {
      await fetch("https://example.com/api/finalizeReport", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ uploadedFile, rows }),
      });
      setPopupMsg("Report Finalized & Submitted!");
      setShowPopup(true);
    } catch (error) {
      console.log("Error finalizing report:", error);
      setPopupMsg("Failed to finalize report.");
      setShowPopup(true);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#DCF2DC" }}>
      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        
        <Header title="Report Entry" />

        {/* ✅ Added PatientDetails Component */}
        <PatientDetails patientData={patientData} />

        <FileUpload uploadedFile={uploadedFile} pickFile={pickFile} />
        <ManualEntry rows={rows} setRows={setRows} addRow={addRow} />

        <ActionControls
          mode="two"
          onDraft={saveDraft}
          onFinalize={finalize}
          allFilled={!!allFilled}
        />
      </ScrollView>

      <Popup showPopup={showPopup} popupMsg={popupMsg} closePopup={() => setShowPopup(false)} />
    </View>
  );
}