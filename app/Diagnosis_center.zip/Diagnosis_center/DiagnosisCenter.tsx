import React, { useState } from "react";
import { View, ScrollView, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { useFonts, IBMPlexSans_400Regular, IBMPlexSans_700Bold } from "@expo-google-fonts/ibm-plex-sans";

import Header from "./components_DiagnosisCenterAnalysis/header";
import SearchBar from "./components_DiagnosisCenterAnalysis/SearchBar";
import PatientCard from "./components_DiagnosisCenterAnalysis/Directory_Patient_Card";

// ✅ NEW IMPORT — Nothing else is changed
import { demoCards } from "./data_diagnosis_center/DiagnosisCenter_demoCards";

export default function DiagnosisCenter() {
  const router = useRouter();

  const [fontsLoaded] = useFonts({
    IBMPlexSans_400Regular,
    IBMPlexSans_700Bold,
  });

  const [patients, setPatients] = useState<any[]>([]);
  const [search, setSearch] = useState<string>("");

  if (!fontsLoaded) return null;

  const filteredPatients = patients.filter(
    (p) =>
      p.name?.toLowerCase().includes(search.toLowerCase()) ||
      p.id?.toString()?.toLowerCase().includes(search.toLowerCase())
  );

  const combinedCards =
    patients.length === 0
      ? search.trim() === ""
        ? demoCards
        : []
      : filteredPatients;

  return (
    <View style={styles.screen}>
      <Header title="Patient Directory" />
      <SearchBar search={search} setSearch={setSearch} />

      <ScrollView contentContainerStyle={{ paddingBottom: 20 }} style={styles.cardsScrollWrapper}>
        <View style={styles.cardsContainer}>
          {combinedCards.map((item, index) => (
            <PatientCard
              key={item.id || index}
              item={item}
              onPress={() =>
                router.push({ pathname: "/ReportQueue", params: { id: item.id } })
              }
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#ffffff",
  },
  cardsScrollWrapper: {
    flex: 1,
    marginTop: 30,
    marginHorizontal: 20,
  },
  cardsContainer: {
    backgroundColor: "#ffffff",
    borderWidth: 2,
    borderColor: "#00aa5d",
    borderRadius: 24,
    padding: 20,
  },
});